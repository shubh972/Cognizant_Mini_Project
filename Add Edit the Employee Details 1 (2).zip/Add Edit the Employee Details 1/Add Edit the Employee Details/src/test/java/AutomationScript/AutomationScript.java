package AutomationScript;

import com.orangehrm.Utils.ExcelUtils;
import main.AddEmployeePage;
import main.EmployeeDetailsPage;
import main.LoginPage;
import main.PIMPage;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.*;
import io.github.bonigarcia.wdm.WebDriverManager;
import java.io.IOException;
import java.time.Duration;

public class AutomationScript {
    private WebDriver driver;
    private LoginPage loginPage;
    private PIMPage pimPage;
    private AddEmployeePage addEmployeePage;
    private EmployeeDetailsPage employeeDetailsPage;
    private final String browser;

    public void hold() {
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt(); // Restore the interrupted status
        }
    }

    @DataProvider(name = "employeeData")
    public Object[][] getEmployeeData() throws IOException {
        return ExcelUtils.getExcelData("src/main/resources/TestData.xlsx");
    }

    @Parameters("browser")
    public AutomationScript(String browser) {
        this.browser = browser;
    }

    @BeforeMethod
    public void setUp() {
        driver = switch (browser.toLowerCase()) {
            case "chrome" -> {
                WebDriverManager.chromedriver().setup();
                yield new ChromeDriver();
            }
            case "edge" -> {
                WebDriverManager.edgedriver().setup();
                yield new EdgeDriver();
            }
            default -> throw new IllegalArgumentException("Browser not supported: " + browser);
        };

        driver.manage().window().maximize();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        loginPage = new LoginPage(driver);
        pimPage = new PIMPage(driver);
        addEmployeePage = new AddEmployeePage(driver);
        employeeDetailsPage = new EmployeeDetailsPage(driver);
    }

    @Test
    public void testAddAndEditAllEmployees() throws IOException {
        // Login once
        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
        hold();
        loginPage.login("Admin", "admin123");
        hold();

        Object[][] allData = ExcelUtils.getExcelData("src/main/resources/TestData.xlsx");
        for (Object[] row : allData) {
            String firstName = row[0].toString();
            String middleName = row[1].toString();
            String lastName = row[2].toString();
            String username = row[3].toString();
            String password = row[4].toString();

            // Add Employee
            pimPage.navigateToPIM();
            hold();
            pimPage.clickAddButton();
            hold();
            addEmployeePage.addEmployee(firstName, middleName, lastName, username, password);
            hold();

            // Navigate back to PIM and search for the employee
            pimPage.navigateToPIM();
            hold();
            pimPage.searchAndEditEmployee(firstName + " " + lastName);
            hold();

            // Edit Employee Details with scrolling
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("arguments[0].scrollIntoView(true);",
                    driver.findElement(org.openqa.selenium.By.xpath("//label[text()='Nationality']")));
            employeeDetailsPage.editEmployeeDetails();
            hold();
        }

        // Logout once after all entries
        loginPage.logout();
        hold();
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}