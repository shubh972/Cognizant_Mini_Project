package com.orangehrm.pages;

import com.orangehrm.base.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class PIMPage extends BasePage {
    private final By pimTab = By.xpath("//span[text()='PIM']/ancestor::a");
    private final By addButton = By.xpath("//button[text()=' Add ']");
    private final By employeeNameSearch = By.xpath("//input[@placeholder='Type for hints...']");
    private final By searchButton = By.xpath("//button[@type='submit' and .=' Search ']");
    private final By searchResults = By.xpath("//div[@class='oxd-table-body']/div");
    private final By editButton = By.xpath("//div[@class='oxd-table-body']/div[1]//button[1]");
    private final By pageLoader = By.cssSelector(".oxd-loading-spinner, .oxd-form-loader");

    public PIMPage(WebDriver driver) {
        super(driver);
    }

    public void navigateToPIM() {
        wait.until(ExpectedConditions.elementToBeClickable(pimTab)).click();
        wait.until(ExpectedConditions.invisibilityOfElementLocated(pageLoader));
    }

    public void clickAddButton() {
        wait.until(ExpectedConditions.elementToBeClickable(addButton)).click();
    }

    public void searchAndEditEmployee(String employeeName) {
        wait.until(ExpectedConditions.elementToBeClickable(employeeNameSearch)).clear();
        wait.until(ExpectedConditions.elementToBeClickable(employeeNameSearch)).sendKeys(employeeName);
        wait.until(ExpectedConditions.elementToBeClickable(searchButton)).click();
        wait.until(ExpectedConditions.invisibilityOfElementLocated(pageLoader));
        wait.until(ExpectedConditions.visibilityOfElementLocated(searchResults));
        wait.until(ExpectedConditions.elementToBeClickable(editButton)).click();
        wait.until(ExpectedConditions.invisibilityOfElementLocated(pageLoader));
    }
}