package com.orangehrm.pages;

import com.orangehrm.base.BasePage;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class EmployeeDetailsPage extends BasePage {
    private final By nationalityDropdown = By.xpath("//label[text()='Nationality']/../following-sibling::div//div[contains(@class,'oxd-select-text')]");
    private final By indianOption = By.xpath("//div[@role='listbox']//span[text()='Indian']");
    private final By genderMaleRadio = By.xpath("//label[normalize-space()='Male']/span");
    private final By maritalStatusDropdown = By.xpath("//label[text()='Marital Status']/../following-sibling::div//div[contains(@class,'oxd-select-text')]");
    private final By singleOption = By.xpath("//div[@role='listbox']//span[text()='Single']");
    private final By saveButton = By.xpath("//button[@type='submit']");
    private final By pageLoader = By.className("oxd-loading-spinner");
    private final By editButton = By.xpath("//button[.=' Edit ']");
    private final By successToast = By.xpath("//div[contains(@class,'oxd-toast') and contains(.,'Success')]");

    public EmployeeDetailsPage(WebDriver driver) {
        super(driver);
    }

    public void editEmployeeDetails() {
        try {
            wait.until(ExpectedConditions.invisibilityOfElementLocated(pageLoader));
            Thread.sleep(2000);

            // If Edit button is present, click it to enable form editing
            if (driver.findElements(editButton).size() > 0) {
                WebElement editBtn = driver.findElement(editButton);
                scrollToElement(editBtn);
                wait.until(ExpectedConditions.elementToBeClickable(editButton)).click();
                Thread.sleep(1000);
            }

            // Set Nationality as Indian
            WebElement nationalityElement = wait.until(ExpectedConditions.presenceOfElementLocated(nationalityDropdown));
            scrollToElement(nationalityElement);
            wait.until(ExpectedConditions.elementToBeClickable(nationalityDropdown)).click();
            Thread.sleep(500);
            wait.until(ExpectedConditions.elementToBeClickable(indianOption)).click();

            // Select Gender as Male
            WebElement genderElement = wait.until(ExpectedConditions.presenceOfElementLocated(genderMaleRadio));
            scrollToElement(genderElement);
            wait.until(ExpectedConditions.elementToBeClickable(genderMaleRadio)).click();

            // Set Marital Status as Single
            WebElement maritalElement = wait.until(ExpectedConditions.presenceOfElementLocated(maritalStatusDropdown));
            scrollToElement(maritalElement);
            wait.until(ExpectedConditions.elementToBeClickable(maritalStatusDropdown)).click();
            Thread.sleep(500);
            wait.until(ExpectedConditions.elementToBeClickable(singleOption)).click();

            // Save the changes
            WebElement saveElement = wait.until(ExpectedConditions.presenceOfElementLocated(saveButton));
            scrollToElement(saveElement);
            wait.until(ExpectedConditions.elementToBeClickable(saveButton)).click();

            // Wait for save operation to complete and success toast
            wait.until(ExpectedConditions.invisibilityOfElementLocated(pageLoader));
            try {
                wait.until(ExpectedConditions.visibilityOfElementLocated(successToast));
            } catch (TimeoutException e) {
                System.out.println("Warning: Save may not have succeeded. Success toast not found. Check for validation errors or required fields.");
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}