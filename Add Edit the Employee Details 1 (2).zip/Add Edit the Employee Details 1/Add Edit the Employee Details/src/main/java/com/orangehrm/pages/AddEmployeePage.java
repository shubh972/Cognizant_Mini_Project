package com.orangehrm.pages;

import com.orangehrm.base.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class AddEmployeePage extends BasePage {
    private final By firstNameField = By.name("firstName");
    private final By middleNameField = By.name("middleName");
    private final By lastNameField = By.name("lastName");
    private final By usernameField = By.xpath("//label[text()='Username']/parent::div/following-sibling::div/input");
    private final By passwordField = By.xpath("//label[text()='Password']/parent::div/following-sibling::div/input");
    private final By confirmPasswordField = By.xpath("//label[text()='Confirm Password']/parent::div/following-sibling::div/input");
    private final By saveButton = By.xpath("//button[text()=' Save ']");
    private final By createLoginDetailsSwitch = By.className("oxd-switch-input");
    private final By pageLoader = By.className("oxd-form-loader");

    public AddEmployeePage(WebDriver driver) {
        super(driver);
    }

    public void addEmployee(String firstName, String middleName, String lastName, String username, String password) {
        // Wait for initial page load and fill basic details
        wait.until(ExpectedConditions.elementToBeClickable(firstNameField));
        driver.findElement(firstNameField).sendKeys(firstName);
        driver.findElement(middleNameField).sendKeys(middleName);
        driver.findElement(lastNameField).sendKeys(lastName);

        // Wait for and scroll to Create Login Details
        wait.until(ExpectedConditions.invisibilityOfElementLocated(pageLoader));
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView(true);", driver.findElement(createLoginDetailsSwitch));
        wait.until(ExpectedConditions.elementToBeClickable(createLoginDetailsSwitch)).click();

        // Fill in login details
        wait.until(ExpectedConditions.elementToBeClickable(usernameField));
        driver.findElement(usernameField).sendKeys(username);
        driver.findElement(passwordField).sendKeys(password);
        driver.findElement(confirmPasswordField).sendKeys(password);

        // Scroll to and click Save
        js.executeScript("arguments[0].scrollIntoView(true);", driver.findElement(saveButton));
        wait.until(ExpectedConditions.elementToBeClickable(saveButton)).click();
        wait.until(ExpectedConditions.invisibilityOfElementLocated(pageLoader));
    }
}