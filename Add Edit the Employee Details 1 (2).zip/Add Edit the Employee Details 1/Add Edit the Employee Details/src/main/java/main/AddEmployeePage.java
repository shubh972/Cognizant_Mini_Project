package main;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

public class AddEmployeePage {
    private final WebDriver driver;
    private final WebDriverWait wait;

    // Fields using By.name()
    private final By firstNameField = By.name("firstName"),
                     middleNameField = By.name("middleName"),
                     lastNameField = By.name("lastName");
    
    // Fields using By.xpath()
    private final By usernameField = By.xpath("//label[text()='Username']/parent::div/following-sibling::div/input"),
                     passwordField = By.xpath("//label[text()='Password']/parent::div/following-sibling::div/input"),
                     confirmPasswordField = By.xpath("//label[text()='Confirm Password']/parent::div/following-sibling::div/input"),
                     saveButton = By.xpath("//button[text()=' Save ']");
    
    // Fields using By.className()
    private final By createLoginDetailsSwitch = By.className("oxd-switch-input"),
                     pageLoader = By.className("oxd-form-loader");

    public AddEmployeePage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }

    public void addEmployee(String firstName, String middleName, String lastName, String username, String password) {
        // Wait for initial page load
        wait.until(ExpectedConditions.elementToBeClickable(firstNameField));
        
        // Fill in basic details
        driver.findElement(firstNameField).sendKeys(firstName);
        driver.findElement(middleNameField).sendKeys(middleName);
        driver.findElement(lastNameField).sendKeys(lastName);

        // Wait for and scroll to Create Login Details
        wait.until(ExpectedConditions.invisibilityOfElementLocated(pageLoader));
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView(true);", driver.findElement(createLoginDetailsSwitch));
        wait.until(ExpectedConditions.elementToBeClickable(createLoginDetailsSwitch)).click();

        // Fill in login details
        wait.until(ExpectedConditions.elementToBeClickable(usernameField));
        driver.findElement(usernameField).sendKeys(username);
        driver.findElement(passwordField).sendKeys(password);
        driver.findElement(confirmPasswordField).sendKeys(password);

        // Scroll to and click Save
        js.executeScript("arguments[0].scrollIntoView(true);", driver.findElement(saveButton));
        wait.until(ExpectedConditions.elementToBeClickable(saveButton)).click();
        
        // Wait for save operation to complete
        wait.until(ExpectedConditions.invisibilityOfElementLocated(pageLoader));
    }
}