package main;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class PIMPage {
    private WebDriver driver;
    private WebDriverWait wait;

    private By pimTab = By.xpath("//span[text()='PIM']/ancestor::a");
    private By addButton = By.xpath("//button[text()=' Add ']");
    private By employeeNameSearch = By.xpath("//input[@placeholder='Type for hints...']");
    private By searchButton = By.xpath("//button[@type='submit' and .=' Search ']");
    private By searchResults = By.xpath("//div[@class='oxd-table-body']/div");
    private By editButton = By.xpath("//div[@class='oxd-table-body']/div[1]//button[1]");
    private By pageLoader = By.cssSelector(".oxd-loading-spinner, .oxd-form-loader");

    public PIMPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }

    public void navigateToPIM() {
        wait.until(ExpectedConditions.elementToBeClickable(pimTab)).click();
        wait.until(ExpectedConditions.invisibilityOfElementLocated(pageLoader));
    }

    public void clickAddButton() {
        wait.until(ExpectedConditions.elementToBeClickable(addButton)).click();
    }

    public void searchAndEditEmployee(String employeeName) {
        // Wait for search field and enter employee name
        wait.until(ExpectedConditions.elementToBeClickable(employeeNameSearch)).clear();
        wait.until(ExpectedConditions.elementToBeClickable(employeeNameSearch)).sendKeys(employeeName);

        // Click search and wait for results
        wait.until(ExpectedConditions.elementToBeClickable(searchButton)).click();
        wait.until(ExpectedConditions.invisibilityOfElementLocated(pageLoader));

        // Wait for search results and click edit
        wait.until(ExpectedConditions.visibilityOfElementLocated(searchResults));
        wait.until(ExpectedConditions.elementToBeClickable(editButton)).click();
        wait.until(ExpectedConditions.invisibilityOfElementLocated(pageLoader));
    }
}